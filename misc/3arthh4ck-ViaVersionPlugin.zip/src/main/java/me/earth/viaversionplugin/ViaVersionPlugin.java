package me.earth.viaversionplugin;

import me.earth.earthhack.api.plugin.Plugin;

@SuppressWarnings("unused")
public class ViaVersionPlugin implements Plugin
{
    @Override
    public void load()
    {
        //ViaFabric
    }

}
